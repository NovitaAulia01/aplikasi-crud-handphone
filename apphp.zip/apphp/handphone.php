<?php
// membuat instance
$dataSiswa=NEW Handphone;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<center><h3>Daftar Handphone</h3>';
$html .='<table class="table table-success table-striped"> <border="1" width="100%">
<thead>
<th>No.</th>
<th>Id Handpone</th>
<th>Merk</th>
<th>Tipe</th>
<th>harga hp</th>
<th>Spesifikasi</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $dataSiswa->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisSiswa){
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisSiswa->id_hp.'</td>
<td>'.$barisSiswa->merk.'</td>
<td>'.$barisSiswa->tipe.'</td>
<td>'.$barisSiswa->harga_hp.'</td>
<td>'.$barisSiswa->spesifikasi.'</td>
<td>
<a class="btn btn-secondary"
href="index.php?file=handphone&aksi=edit&id='.$barisSiswa->id_hp.'">Edit</a>
<a class="btn btn-dark"
href="index.php?file=handphone&aksi=hapus&id='.$barisSiswa->id_hp.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<form method="POST"
action="index.php?file=handphone&aksi=simpan">';
$html .='<p>ID HANDPONE<br/>';
$html .='<input type="text" name="txtidhp"
placeholder="Masukan id Handphone" autofocus/></p>';
$html .='<p>MERK<br/>';
$html .='<input type="text" name="txtmerk"
placeholder="Masukan merk" size="30" required/></p>';
$html .='<p>TIPE<br/>';
$html .='<input type="text" name="txttipe"placeholder="Masukan tipe hp" size="30" required/>,';
$html .='<p>HARGA HANDPONE<br/>';
$html .='<input type="text" name="txthargahp"
placeholder="Masukan harga hp" size="30" required/>,';
$html .='<p>SPESIFIKASI<br/>';
$html .='<input type="text" name="txtspesifikasi"
placeholder="Masukan spesifikasi" size="30" required/>,';
$html .='<p><input type="submit" class="btn btn-primary" name="tombolSimpan"
value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'id_hp'=>$_POST['txtidhp'],
'merk'=>$_POST['txtmerk'],
'tipe'=>$_POST['txttipe'],
'harga_hp'=>$_POST['txthargahp'],
'spesifikasi'=>$_POST['txtspesifikasi'],
);
// simpan siswa dengan menjalankan method simpan
$dataSiswa->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=handphone&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data siswa
$Handphone=$dataSiswa->detail($_GET['id']);
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST"
action="index.php?file=handphone&aksi=update">';
$html .='<p>ID HANDPONE<br/>';
$html .='<input type="text" name="txtidhp" value="'.$Handphone->id_hp.'" placeholder="Masukan id Handphone" autofocus/></p>';
$html .='<p>MERK<br/>';
$html .='<input type="text" name="txtmerk" value="'.$Handphone->merk.'" placeholder="Masukan merk" size="30" required/></p>';
$html .='<p>TIPE<br/>';
$html .='<input type="text" name="txttipe" value="'.$Handphone->tipe.'" placeholder="Masukan tipe hp" size="30" required/>,';
$html .='<p>HARGA HANDPONE<br/>';
$html .='<input type="text" name="txthargahp" value="'.$Handphone->harga_hp.'" placeholder="Masukan harga hp" size="30" required/>,';
$html .='<p>SPESIFIKASI<br/>';
$html .='<input type="text" name="txtspesifikasi" value="'.$Handphone->spesifikasi.'" placeholder="Masukan Spesifikasi" size="30" required/>,';
$html .='<p><input type="submit" class="btn btn-primary" name="tombolSimpan"
value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='update') {
$data=array(
'merk'=>$_POST['txtmerk'],
'tipe'=>$_POST['txttipe'],
'harga_hp'=>$_POST['txthargahp'],
'spesifikasi'=>$_POST['txtspesifikasi'],
);
$dataSiswa->update($_POST['txtidhp'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=handphone&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$dataSiswa->hapus($_GET['id']);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=handphone&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>