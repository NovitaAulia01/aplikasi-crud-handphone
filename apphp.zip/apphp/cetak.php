<!DOCTYPE html>
<html>
<head>
 <title>Panduancode Cetak laporan PDF Di PHP Dan MySQLi</title>
</head>
<body>
 <style type="text/css">
 body{
 font-family: sans-serif;
 }
 table{
 margin: 20px auto;
 border-collapse: collapse;
 }
 table th,
 table td{
 border: 1px solid #3c3c3c;
 padding: 3px 8px;

 }
 a{
 background: blue;
 color: #fff;
 padding: 8px 10px;
 text-decoration: none;
 border-radius: 2px;
 }

    .tengah{
        text-align: center;
    }
 </style>
 <table>
 <tr>
<th>No.</th>
<th>Id Handpone</th>
<th>Merk</th>
<th>Tipe</th>
<th>harga hp</th>
<th>Spesifikasi</th>
 </tr>
 <?php 
 // koneksi database
 $koneksi = mysqli_connect("localhost","root","","apl_hp");

 // menampilkan data pegawai
 $data = mysqli_query($koneksi,"select * from hp");
 while($d = mysqli_fetch_array($data)){
 ?>
 <tr>
 <td style='text-align: center;'><?php echo $d['id_hp'] ?></td>
 <td><?php echo $d['merk']; ?></td>
 <td><?php echo $d['tipe']; ?></td>
 <td><?php echo $d['harga_hp']; ?></td>
 <td><?php echo $d['Spesifikasi']; ?></td>
 </tr>
 <?php 
 }
 ?>
    </table>
    <script>
 window.print();
 </script>
</body>
</html>